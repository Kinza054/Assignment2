using System.Data;
using System.Windows.Forms;

namespace Assignment_part2
{
    public partial class Form1 : Form
    {
        DataTable dt = new DataTable();
        public Form1()
        {
            InitializeComponent();
        }

        private void dgvData_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        public void createnewrow()
        {
            if (dt.Rows.Count <= 0)
            {
                DataColumn dc1 = new DataColumn("Course Code", typeof(string));
                DataColumn dc2 = new DataColumn("Course Title", typeof(string));
                DataColumn dc3 = new DataColumn("Obtained Marks", typeof(int));
                DataColumn dc4 = new DataColumn("Grade", typeof(string));
                DataColumn dc5 = new DataColumn("Status", typeof(string));

                dt.Columns.Add(dc1);
                dt.Columns.Add(dc2);
                dt.Columns.Add(dc3);
                dt.Columns.Add(dc4);
                dt.Columns.Add(dc5);
            }

            dt.Rows.Add(txt_courseCode.Text, txt_courseTitle.Text,
                        Convert.ToInt32(txt_obtainedMarks.Text), txt_grade.Text, txt_status.Text);

            dgvData.DataSource = dt;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn_book_Click(object sender, EventArgs e)
        {
            createnewrow();

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
