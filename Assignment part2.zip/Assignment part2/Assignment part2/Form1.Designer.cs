﻿namespace Assignment_part2
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvData = new DataGridView();
            btnPrint = new Button();
            btnExit = new Button();
            label1 = new Label();
            txt_courseCode = new TextBox();
            label2 = new Label();
            txt_courseTitle = new TextBox();
            label3 = new Label();
            txt_obtainedMarks = new TextBox();
            label4 = new Label();
            txt_grade = new TextBox();
            label5 = new Label();
            txt_status = new TextBox();
            btn_book = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvData).BeginInit();
            SuspendLayout();
            // 
            // dgvData
            // 
            dgvData.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvData.Location = new Point(31, 154);
            dgvData.Name = "dgvData";
            dgvData.RowHeadersWidth = 62;
            dgvData.Size = new Size(918, 221);
            dgvData.TabIndex = 0;
            dgvData.CellContentClick += dgvData_CellContentClick;
            // 
            // btnPrint
            // 
            btnPrint.Location = new Point(775, 416);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(65, 34);
            btnPrint.TabIndex = 1;
            btnPrint.Text = "Print";
            btnPrint.UseVisualStyleBackColor = true;
            // 
            // btnExit
            // 
            btnExit.Location = new Point(882, 416);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(67, 34);
            btnExit.TabIndex = 2;
            btnExit.Text = "Exit";
            btnExit.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 54);
            label1.Name = "label1";
            label1.Size = new Size(111, 25);
            label1.TabIndex = 3;
            label1.Text = "course Code";
            // 
            // txt_courseCode
            // 
            txt_courseCode.Location = new Point(136, 50);
            txt_courseCode.Multiline = true;
            txt_courseCode.Name = "txt_courseCode";
            txt_courseCode.Size = new Size(78, 31);
            txt_courseCode.TabIndex = 4;
            txt_courseCode.TextChanged += textBox1_TextChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(220, 56);
            label2.Name = "label2";
            label2.Size = new Size(96, 25);
            label2.TabIndex = 5;
            label2.Text = "courseTitle";
            label2.Click += label2_Click;
            // 
            // txt_courseTitle
            // 
            txt_courseTitle.Location = new Point(309, 50);
            txt_courseTitle.Name = "txt_courseTitle";
            txt_courseTitle.Size = new Size(180, 31);
            txt_courseTitle.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(489, 54);
            label3.Name = "label3";
            label3.Size = new Size(131, 25);
            label3.TabIndex = 7;
            label3.Text = "obtainedMarks";
            // 
            // txt_obtainedMarks
            // 
            txt_obtainedMarks.Location = new Point(615, 51);
            txt_obtainedMarks.Name = "txt_obtainedMarks";
            txt_obtainedMarks.Size = new Size(68, 31);
            txt_obtainedMarks.TabIndex = 8;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(685, 55);
            label4.Name = "label4";
            label4.Size = new Size(58, 25);
            label4.TabIndex = 9;
            label4.Text = "grade";
            // 
            // txt_grade
            // 
            txt_grade.Location = new Point(739, 53);
            txt_grade.Name = "txt_grade";
            txt_grade.Size = new Size(44, 31);
            txt_grade.TabIndex = 10;
            txt_grade.TextChanged += textBox4_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(787, 57);
            label5.Name = "label5";
            label5.Size = new Size(59, 25);
            label5.TabIndex = 11;
            label5.Text = "status";
            // 
            // txt_status
            // 
            txt_status.Location = new Point(847, 55);
            txt_status.Name = "txt_status";
            txt_status.Size = new Size(85, 31);
            txt_status.TabIndex = 12;
            // 
            // btn_book
            // 
            btn_book.Location = new Point(858, 102);
            btn_book.Name = "btn_book";
            btn_book.Size = new Size(74, 34);
            btn_book.TabIndex = 13;
            btn_book.Text = "Book";
            btn_book.UseVisualStyleBackColor = true;
            btn_book.Click += btn_book_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(255, 192, 192);
            ClientSize = new Size(980, 492);
            Controls.Add(btn_book);
            Controls.Add(txt_status);
            Controls.Add(label5);
            Controls.Add(txt_grade);
            Controls.Add(label4);
            Controls.Add(txt_obtainedMarks);
            Controls.Add(label3);
            Controls.Add(txt_courseTitle);
            Controls.Add(label2);
            Controls.Add(txt_courseCode);
            Controls.Add(label1);
            Controls.Add(btnExit);
            Controls.Add(btnPrint);
            Controls.Add(dgvData);
            Name = "Form1";
            Text = "Kinza Shahzadi";
            TransparencyKey = Color.FromArgb(255, 192, 192);
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvData).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvData;
        private Button btnPrint;
        private Button btnExit;
        private Label label1;
        private TextBox txt_courseCode;
        private Label label2;
        private TextBox txt_courseTitle;
        private Label label3;
        private TextBox txt_obtainedMarks;
        private Label label4;
        private TextBox txt_grade;
        private Label label5;
        private TextBox txt_status;
        private Button btn_book;
    }
}
